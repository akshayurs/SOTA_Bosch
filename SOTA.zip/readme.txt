install modules 
>> pip install cryptography rsa

1. Run generate_keys.py
    >> input: car

2. Run generate_keys.py
    >> input: cloud

3. Run calculate_signature.py

4. Run verify_signature.py

5. Run encrypt_data.py

6. Run decrypt_data.py

